// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBK3JwG8PEEhyeM8vTRHuO-CWsV0OaVa6w",
  authDomain: "modulspectratest.firebaseapp.com",
  projectId: "modulspectratest",
  storageBucket: "modulspectratest.appspot.com",
  messagingSenderId: "1088136697187",
  appId: "1:1088136697187:web:2236ff295eb98a5ef3ef56",
  measurementId: "G-W8KHVP7HQM"
};

// Initialize Firebase
initializeApp(firebaseConfig);
